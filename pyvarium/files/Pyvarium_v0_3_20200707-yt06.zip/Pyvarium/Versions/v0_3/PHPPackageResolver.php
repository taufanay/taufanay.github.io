<?php
require_once 'PHPModuleService.php';

$path = getcwd();
$method = $argv[1] ?? null;
$pathInfo = pathinfo($path);
$packageName = $pathInfo['basename'];

if ($method == 'init') {
	$initFileName = '__init__.php';
	$moduleFileExtension = 'php';
	$packageAttributes = [
		'meta' => null,
	];
	$moduleAttributes = array();
	
	if (file_exists($initFileName)) {
		include($initFileName);
		$packageAttributes['meta'] = defined("\\$packageName\\meta") ? constant("\\$packageName\\meta") : null;
	}
	
	foreach (glob($path.DIRECTORY_SEPARATOR.'*.php') as $fullFilename) {
		$pathInfo = pathinfo($fullFilename);
		$filename = $pathInfo['basename'];
		$moduleName = $pathInfo['filename'];
		if ($filename != $initFileName || substr($filename,-4) != '.'.$moduleFileExtension) {			
			include($filename);
			
			$attributes = [
				'meta' => defined("\\$packageName\\$moduleName\\meta") ? constant("\\$packageName\\$moduleName\\meta") : null,
				'canRun' => is_callable("\\$packageName\\$moduleName\\run"),
				'canView' => is_callable("\\$packageName\\$moduleName\\view"),
			];
			
			$moduleAttributes[$moduleName] = $attributes;
		}
	}
	
	echo json_encode(['packageAttributes' => $packageAttributes, 'moduleAttributes' => $moduleAttributes]);
}
else if ($method == 'run') {
	$moduleName = $argv[2] ?? null;
	$args = $argv[3] ?? null;
	$serviceData = $argv[4] ?? null;
	require_once $moduleName.'.php';
	$run = "\\$packageName\\$moduleName\\run";
	$view = "\\$packageName\\$moduleName\\view";
	$result = $run($args, $serviceData);
	$resultView = $view($result, $serviceData);
	
	echo json_encode([
		'meta' => defined("\\$packageName\\$moduleName\\meta") ? constant("\\$packageName\\$moduleName\\meta") : null,
		'result' => $result,
		'resultView' => $resultView]);
}
