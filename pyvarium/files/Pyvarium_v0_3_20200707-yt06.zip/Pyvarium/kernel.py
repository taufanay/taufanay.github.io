import sys
import os
import types
from PySide2.QtWidgets import QApplication, QDesktopWidget, QStyleFactory, QMainWindow, QWidget, QPushButton, QHBoxLayout

profile_path = './_profile'
initial_collection_path = './Collections/Welcome'
app_version_default = 'v0_3'

def existsVersion(version):
	exists = os.path.isdir(app_dir + '/Versions/' + version)
	if not exists: 
		print('version ' + version + ' not exists')
		sys.exit()
	return exists

app_dir = os.path.dirname(os.path.realpath(__file__))
app_version = sys.argv[1] if len(sys.argv) > 1 and existsVersion(sys.argv[1]) else app_version_default
app_profile = ''
mainWindowController = None
mainPanelController = None
session = {}

# append application version path

def initApp():
	# Qt Application
	app = QApplication(sys.argv)
	app.setApplicationName("Pyvarium")
	app.setStyle(QStyleFactory.create('Fusion'))
	return app

def initWindow(app, MainWindowController, MainPanelController):
	global mainWindowController
	global mainPanelController

	window = None
	if app_version in ['v0_2','v0_3']:
		mainWidget = MainPanelController(initialCollectionPath=initial_collection_path)
		window = MainWindowController(app, mainWidget, appVersion=app_version)
	else:
		mainPanelController = MainPanelController(initialSourcePath=initial_collection_path)
		mainWindowController = MainWindowController(app, mainPanelController, appVersion=app_version)
		window = mainWindowController.window()
		mainPanelController.initWindow(window)

	window.resize(960, 540)
	qtRectangle = window.frameGeometry()
	centerPoint = QDesktopWidget().availableGeometry().center()
	qtRectangle.moveCenter(centerPoint)
	window.move(qtRectangle.topLeft())
	return window

def startApp(app, window):
	window.show()
	sys.exit(app.exec_())

