import sys
import kernel

if __name__ == "__main__":
	sys.path.append(kernel.app_dir + '/Versions/' + kernel.app_version)
	
	if kernel.app_version == 'v0_4':
		from App.GUIController.MainWindow import MainWindowController
		from App.GUIController.MainPanel import MainPanelController
	else:
		from App.MainWindow import MainWindow as MainWindowController
		from App.MainWidget import MainWidget as MainPanelController

	app = kernel.initApp()
	window = kernel.initWindow(app, MainWindowController, MainPanelController)
	kernel.startApp(app, window)

