"""
Package magic file
"""

import sys
import os
from PySide2.QtWidgets import QApplication, QDesktopWidget, QStyleFactory

__import__(__name__ + '.Versions.v0_4.App.Applet')
MainWidgetHolder = getattr(sys.modules[__name__ + '.Versions.v0_4.App.Applet'], 'MainWidgetHolder')

def run(args = None, **kwargs):
	window = kwargs['window']
	mainWidgetHolder = MainWidgetHolder()
	mainWidgetHolder.initWindow(window)
	return mainWidgetHolder.widget()
	
