import os
import time

from threading import Timer
from PySide2.QtCore import Signal, QObject
from PySide2.QtMultimedia import QSound

""" global variables """
path = None
fileNames = ['bel']
player = None
duration = {
	'bel':2,
	'noantrian':2,
	'keloket':2.5,}

""" class to manage Qt threading for QSound """
class SignalHelper(QObject):
	doPlay = Signal()
	def __init__(self):super().__init__()
	def play(self):self.doPlay.emit()

""" formating sound file path by name from argument """
def getSoundFile(name):
	return path + '/files/demo6/{}.wav'.format(name)

""" fail if sound file not exists """
def checkFile(name):
	f = getSoundFile(name)
	if not os.path.isfile(f): raise Exception('file ' + f + ' not found')

""" Pyvarium run entry point """
def run(args, **kwargs):
	global path, fileNames, player
	path = kwargs['path']
	tmpFileNames = args.split()
	
	for name in tmpFileNames:
		try:
			int(name)
			for c in name:
				checkFile(c)
				fileNames.append(c)
		except:
			checkFile(name)
			fileNames.append(name)

	player = SignalHelper()
	player.doPlay.connect(playing)
	player.play()

	return {
		'status':'ok',
		'message': str(len(fileNames)) + ' sounds found',
	}

""" play sound and create timer to trigger signal helper """
def playing():
	name = fileNames.pop(0)
	QSound.play(getSoundFile(name))
	if fileNames:
		Timer(duration[name] if name in duration else 1, player.play).start()


