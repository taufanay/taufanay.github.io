import requests
import json

meta = {
	"viewTextFormat":"html"
}

apiURL = "https://en.wikipedia.org/w/api.php"

def getWikiPageInfo(search):
	query = {
		'action':'query',
		'prop':'extracts',
		'format':'json',
		'exintro':1,
		'redirects':1,
		'titles':search,
	}
	response = requests.get(apiURL, query)
	content = response.text
	data = json.loads(content)
	pages = data['query']['pages']
	pageId = list(pages.keys())[0]
	pageInfo = pages[pageId] if int(pageId) > 0 else None
	return pageInfo

def run(args, **kwargs):
	search = args
	if len(search) == 0: result = {'status':'fail','message':'provide a search text'}
	else:
		pageInfo = getWikiPageInfo(search)
		if pageInfo:
			result = {
				'status':'ok',
				'message':'article found',
				'data':{
					'search':search,
					'pageInfo':pageInfo
			}}
		else:
			result = {'status':'fail','message':'article not found'}
	return result

def view(result, **kwargs):
	data = result['data']
	pageInfo = data['pageInfo']
	return f"""<p>search: <b>{data['search']}</b></p>

<h2>{pageInfo['title']}</h2>
{pageInfo['extract']}
(<a href="https://en.wikipedia.org/?curid={pageInfo['pageid']}" title="see in wikipedia">wikipedia</a>)
"""
