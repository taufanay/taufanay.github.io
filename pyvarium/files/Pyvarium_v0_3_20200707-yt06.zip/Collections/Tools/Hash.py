import hashlib
import sys

meta = {
	'shortDesc': 'generates various hash values from general parameter'
}

def hash(hashType, value):
	hasher = hashlib.new(hashType)
	hasher.update(value.encode())
	return hasher.hexdigest()

def run(params, **kargs):	
	md5Result = hash('md5', params)
	
	if len(params) > 0:
		return {
			'status': 'ok',
			'message': "MD5: " + md5Result,
			'data': {
				'text': params,
				'MD5': md5Result,
				'SHA1': hash('sha1', params),
				'SHA256': hash('sha256', params),
				'SHA384': hash('sha384', params),
				'SHA512': hash('sha512', params),
			} 
		}
	else:
		return {
			'status': 'fail',
			'message': 'provide a value',
			'data': None,
		}

def view(result, **kargs):
	if not result['data']: return None
	else: return f"""Hash Result

Orginal Text:
{result['data']['text']}

MD5:
{result['data']['MD5']}

SHA1:
{result['data']['SHA1']}

SHA256:
{result['data']['SHA256']}

SHA384:
{result['data']['SHA384']}

SHA512:
{result['data']['SHA512']}
"""

if __name__ == '__main__':
	param = sys.argv[1]
	print(view(run(param)))
