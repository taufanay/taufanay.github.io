meta = {
	'title': 'Documentation',
	'checked': True,
	'resultTextFormat': 'html',
}
	
def run(params, **kargs):
	return {
		'status': 'ok',
		'message': 'click to view',
	}

def view(result, **kargs):
	return """<h1>Documentation</h1>

<p>	
There are 2 main components in this program, <b>Package</b> directory and <b>Module</b> scripts.
Not to be consufed, the term "Package" and "Module" are also Python terminology, however we will use them interchangably in the context of this program.
</p>

<h2>Package</h2>
<p>
This directory where modules reside. For example, the current package of this Documentation module can be viewed in the ./Collections/Welcome directory that should coming with this program.
</p>
<p>
This is an actually an implementation of Python package where we can put any initialization script in a __init__.py file inside this directory.
In the initialization file, we can put our metadata variable to interact with this program GUI.
Throughout the samples in this documentation we will use ~/Demo/ as our Package directory.
</p>

<h3><i>meta</i></h3>
<p>
<pre>
# ~/Demo/__init__.py
meta = {
    'autorun': True|False
}
</pre>
</p>
<p>
All key-value in Package metadata are optional.
The metadata variable and the initialization file itself is also optional.
</p>

<h2>Module</h2>
<p>
A module is a file where the script we want to run and view either in Modules Table or Result Viewer.
To interact with GUI, module should implement the corresponding attributes.
</p>

<h3><i>meta</i></h3>
<p>
	To set general module behaviour, use <b>meta</b> property which could have following entries:
	<ul>
		<li>title</li>
		<li>checked</li>
		<li>requireResultViewer</li>
		<li>resultTextFormat</li>
	</ul>
</p>

<h3><i>run</i></h3>
<p>
	To set the result value when user click the run button, use <b>run</b> function with parameter defined as:
	(params, **kwargs) and return value a dictionary with mandatory item: <b>status</b> and <b>message</b>.
</p>

<h3><i>view</i></h3>
<p>
	To set the result preview area in program, module must be run first by user, and regardless the result value,
	program will pass it to the <b>view</b> function is any. View function defined with parameter (result, **kwargs) and
	can return at least 2 kind data types, string and instance of QWidget.
</p>
<p>
	The string return value defined it's format from the <b>meta</b> attribute above, so the program understand how to show it correctly
	with plain text being the default format.
</p>
"""
