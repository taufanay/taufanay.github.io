meta = {
	'title': 'Getting Started',
	'checked': True,
	'resultTextFormat': 'html'
}
	
def run(params, **kargs):
	return {
		'status': 'ok',
		'message': 'click to view',
	}

def view(result, **kargs):
	return """<h1>Getting Started</h1>

<p>
Welcome to Pyvarium program.
</p>

<p>
Pyvarium is a simple general purpose tool to run one or more of our own custom Python scripts as so called "module".
The result output of these modules can be further processed to be viewed either in textual format or graphical representation.
</p>

<p>
This program will handles all the GUI need for the module script execution and result viewing.
</p>

<h3>Use Cases</h3>
<p>
I found that this approach can be used easily for several use cases such as:
<ul>
	<li>Monitoring,</li>
	<li>Execution,</li>
	<li>Automation,</li>
	<li>Analysis,</li>
	<li>Data generation,</li>
	<li>User interactivity,</li>
	<li>etc.</li>
</ul>
</p>

<h3>First Module</h3>
<p>
To get started, simply create a Python file that implement following attributes in a special directory.
This file will be called "Module" and the directory will be called "Package".
The Package directory will be referenced later on in the main program.
</p>

<p style="background-color:snow;color:gray;padding:10px;">
<pre>
# ./Collections/Demo/Basic.py

meta = {
    'title': "First Module"
}

def run(params, **kwargs):
    return {
      "status": "ok",
      "message": "Hello World",
    }

# optional for using Result Viewer
def view(result, **kwargs):
    return "You said: " + result['message']
</pre>
</p>

<p>
You can try using the example above to create your first module.
Complete specifications can be viewed in the next Documentation module of this Welcome package.
</p>
"""
