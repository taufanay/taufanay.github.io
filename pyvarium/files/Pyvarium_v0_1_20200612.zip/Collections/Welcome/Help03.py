from PySide2.QtWidgets import QScrollArea, QVBoxLayout, QLabel

meta = {
	'title': 'Functionality',
	'checked': True,
	'resultTextFormat': 'html',
}

def run(params, **kargs):
	return {
		'status': 'ok',
		'message': 'click to view',
	}

def view(result, **kargs):
	return """<h1>Functionalities</h1>
<p>
	This program has following functionalities:
</p>

<ol>
	<li>Load/reload a modules package</li>
	<li>Run single module</li>
	<li>Run multiple checked modules</li>
	<li>Run multiple checked modules directly when a package loaded</li>
	<li>Reprocess and view module result as plain text, HTML, or PySide2 GUI widget</li>
	<li>View module result in it's raw format (dictionary)</li>
	<li>View module source code to review it before or after running it</li>
	<li>Use General Parameter textbox to provide argument to module</li>
	<li>Show/hide General Parameter textbox and Result Viewer section</li>
</ol>

<p>
All modules are practically a small program that can access all resources in this computer.
That mean it can run command, store data, use network interface, etc through the SDK library.
</p>

<p>
The Modules Table and Result Viewer can be used to provided a kind of user interaction.
It as powerful as any program running in this computer, thus should be handled with very care.
</p>
"""

