
def run(params, **kwargs):
	result = {'status':'ok', 'message':'Hello World'}
	return result

def view(result, **kwargs):
	view = """You said:
{}
""".format(result['message'])
	return view

if __name__ == '__main__':
	print(run(None)['message'])
