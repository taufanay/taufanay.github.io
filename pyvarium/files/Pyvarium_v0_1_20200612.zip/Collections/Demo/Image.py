from PySide2.QtGui import QPixmap
from PySide2.QtWidgets import QLabel

img = '/home/bob/Pictures/python-powered.png'

def run(params, **kwargs):
	return {
		'status':'ok',
		'message': img
	}

def view(result, **kwargs):
	view = QLabel()
	pixmap = QPixmap(img)
	view.setPixmap(pixmap)
	return view
