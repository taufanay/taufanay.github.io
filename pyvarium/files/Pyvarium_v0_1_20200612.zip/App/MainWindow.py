from PySide2.QtCore import Qt, Slot, Signal
from PySide2.QtWidgets import QMainWindow, QMessageBox, QLabel, QAction, QVBoxLayout, QPushButton

class MainWindow(QMainWindow):
	def __init__(self, app, mainWidget):
		QMainWindow.__init__(self)
		
		self.app = app
		self.originalPalette = app.palette()
		self.baseTitle = "Pyvarium v0.1"
		
		# Modal Dialog
		self.aboutDialog = QMessageBox()
		self.aboutDialog.setModal(True)
		self.aboutDialog.setWindowTitle('About')
		self.aboutDialog.setText('Pyvarium v0.1')

		# Menu
		self.menu = self.menuBar()
		self.file_menu = self.menu.addMenu("File")
		self.view_menu = self.menu.addMenu("View")
		
		# New Action
		new_action = QAction("New", self)
		new_action.triggered.connect(mainWidget.startNew)
		new_action.setShortcut("Ctrl+N")
		self.file_menu.addAction(new_action)
		
		# Exit QAction
		exit_action = QAction("Exit", self)
		exit_action.setShortcut("Ctrl+Q")
		exit_action.triggered.connect(self.quitApp)
		self.file_menu.addAction(exit_action)
		
		# View Actions
		generalParam_action = QAction("General Parameter", self)
		generalParam_action.triggered.connect(mainWidget.toggleGeneralParameter)
		self.view_menu.addAction(generalParam_action)
		
		# Toggle Result Viewer action
		resultViewer_action = QAction("Result Viewer", self)
		resultViewer_action.triggered.connect(mainWidget.toggleResultViewer)
		self.view_menu.addAction(resultViewer_action)
		
		self.view_menu.addSeparator()
		
		# Show about
		about_action = QAction("About", self)
		about_action.triggered.connect(self.showAboutDialog)
		self.view_menu.addAction(about_action)
		
		# Status
		self.statusLabel = QLabel()
		self.statusBar = self.statusBar()
		self.statusBar.addWidget(self.statusLabel)

		self.setCentralWidget(mainWidget)
		self.setWindowTitle(self.baseTitle)
		
		mainWidget.statusChanged.connect(self.setStatusLabel)
	
	@Slot()
	def quitApp(self, checked):
		self.app.quit()
		
	@Slot()
	def setStatusLabel(self, text):
		self.statusLabel.setText(text)
		
	@Slot()
	def setPackageTitle(self, title):
		self.setWindowTitle(self.baseTitle + ' - ' + title)
		
	@Slot()
	def showAboutDialog(self):
		self.aboutDialog.show()
