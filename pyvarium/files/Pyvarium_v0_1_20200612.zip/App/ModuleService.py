import os
import sys
import collections
from importlib import reload
	
class ModuleService():
	def __init__(self, path):
		self.lastResults = {}
		self.moduleNames = []
		self.path = path
		self.packageMeta = {}
		self.packageName = os.path.basename(path)

		sys.path.append(os.path.dirname(self.path))
		packageInitModule = __import__(self.packageName)
		if packageInitModule:
			if hasattr(packageInitModule, 'meta'):
				self.packageMeta = getattr(packageInitModule, 'meta')
		modulePath = self.path
		files = os.listdir(modulePath)
		for fname in files:
			if os.path.isfile(os.path.join(modulePath,fname)) and (fname != '__init__.py') and fname[-3:] == '.py':
				self.moduleNames.append(fname[:-3])
		self.moduleNames.sort()
	
	def getModule(self, moduleName):
		if not moduleName in self.moduleNames: raise Exception(moduleName + " is not registered in module service")
		fullModuleName = self.packageName + '.' + moduleName
		if fullModuleName not in sys.modules:
			__import__(fullModuleName)
		module = sys.modules[fullModuleName]
		return module

	def reloadModule(self, moduleName):
		return reload(self.getModule(moduleName))

	def getModuleLastResult(self, moduleName):
		result = None
		if moduleName in self.lastResults:
			result = self.lastResults[moduleName]
		return result
	
	def getModuleMeta(self, moduleName):
		module = self.getModule(moduleName)
		if hasattr(module, 'meta'):
			return getattr(module, 'meta')
		else:
			return {}

	def runModule(self, moduleName, params):
		#module = self.reloadModule(moduleName)
		module = self.getModule(moduleName)
		if hasattr(module, 'run'):
			definition = getattr(module, 'run')
			result = definition(params, moduleService=self)
			if isinstance(result, collections.Mapping):
				self.lastResults[moduleName] = result
			else:
				self.lastResults[moduleName] = {
					'status': 'n/a',
					'message': '(invalid result type)',
					'data': result
				}
		else:
			self.lastResults[moduleName] = {
				'status': 'n/a',
				'message': '(nothing to run)',
				'data': None
			}
			
		return self.lastResults[moduleName]
	
	def isModuleHasResultView(self, moduleName):
		return hasattr(self.getModule(moduleName), 'view')
	
	def getModuleResultView(self, moduleName):
		module = self.getModule(moduleName)
		if hasattr(module, 'view'):
			return getattr(module, 'view')(self.getModuleLastResult(moduleName), moduleService=self)
	
	def getModuleSource(self, moduleName):
		f = open(os.path.join(self.path, moduleName + '.py'))
		source = f.read()
		f.close()
		return source
		
	def destroy(self):
		sys.path.remove(os.path.dirname(self.path))
		del sys.modules[self.packageName]
		for moduleName in self.moduleNames:
			moduleFullName = self.packageName + "." + moduleName
			if moduleFullName in sys.modules: del sys.modules[moduleFullName]
