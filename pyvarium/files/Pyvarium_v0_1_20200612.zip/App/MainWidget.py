import os
import json
import pprint
from App.ModuleService import ModuleService
from PySide2.QtCore import Qt, Slot, Signal
from PySide2.QtGui import QFont
from PySide2.QtWidgets import (QWidget, QHeaderView, QHBoxLayout, QVBoxLayout, QLabel, QLineEdit,
								QPushButton, QTableWidget, QTableWidgetItem, QSplitter,
								QPlainTextEdit, QTextEdit, QScrollArea, QTabWidget, QGroupBox,
								QItemDelegate, QLineEdit)

class QTableWidgetDisabledItem(QItemDelegate):
    def __init__(self, parent=None):
        QItemDelegate.__init__(self, parent)

    def createEditor(self, parent, option, index):
        item = QLineEdit(parent)
        item.setReadOnly(True)
        #item.setEnabled(False)
        return item

    def setEditorData(self, editor, index):
        editor.blockSignals(True)
        editor.setText(index.model().data(index))
        editor.blockSignals(False)

    def setModelData(self, editor, model, index):
        model.setData(index, editor.text())

class MainWidget(QWidget):
	statusChanged = Signal(str)
	
	def __init__(self):
		QWidget.__init__(self)
		
		#-- setup general purpose values
		self.window = None
		self.moduleService = None
		self.tableItems = 0
		self.resultViewPool = {}
		self.resultCurrentModuleName = ''
		self.resultWidgetViewer = QWidget()
		self.resultWidgetViewer.setLayout(QVBoxLayout())
		self.resultWidgetViewer.hide()
		self.resultPlainTextViewer = QPlainTextEdit()
		self.resultPlainTextViewer.setReadOnly(True)
		self.resultPlainTextViewer.hide()
		self.resultHTMLViewer = QTextEdit()
		self.resultHTMLViewer.setReadOnly(True)
		self.resultHTMLViewer.hide()
		
		#-- setup top widgets
		from main import initialCollectionPath	
		self.txtSourcePath = QLineEdit()
		self.txtSourcePath.setText(initialCollectionPath)
		self.btnReload = QPushButton("Connect")
		self.btnReload.clicked.connect(self.reloadCollection)
		
		#-- setup globalParamsBox widgets
		self.txtGlobalParam = QLineEdit()
		self.globalParamBox = QWidget()
		self.globalParamBox.setLayout(QVBoxLayout())
		self.globalParamBox.layout().setMargin(0)
		self.globalParamBox.layout().addWidget(QLabel('General Parameter'))
		self.globalParamBox.layout().addWidget(self.txtGlobalParam)
		self.globalParamBox.hide()
		
		# Modules Table
		self.table = QTableWidget()
		self.table.setColumnCount(3)
		self.table.setHorizontalHeaderLabels(["Module", "Status", "Message"])
		self.table.setColumnWidth(0, 200)
		self.table.setColumnWidth(1, 60)
		self.table.horizontalHeader().setStretchLastSection(True)
		self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
		self.table.cellClicked.connect(self.cellClicked)
		self.table.itemSelectionChanged.connect(self.itemSelectionChanged)
		self.table.setItemDelegateForColumn(2, QTableWidgetDisabledItem())

		#-- setup run buttons
		self.btnRunSourceModule = QPushButton("Run")
		self.btnRunSourceModule.setEnabled(False)
		self.btnRunSourceModule.clicked.connect(self.runModuleItem)
		self.btnRunSourceModules = QPushButton("Run Checked")
		self.btnRunSourceModules.clicked.connect(self.runAllModuleItems)
		
		#-- setup Left side
		leftLayout = QVBoxLayout()
		leftLayout.addWidget(self.globalParamBox)
		leftLayout.addWidget(self.table)
		leftLayout.addWidget(self.btnRunSourceModule)
		leftLayout.addWidget(self.btnRunSourceModules)
		leftGroupBox = QGroupBox('Modules')
		leftGroupBox.setLayout(leftLayout)
		
		#-- setup result box
		self.resultInfoLabel = QLabel()
		self.resultViewer = QWidget()
		self.resultViewer.setLayout(QVBoxLayout())
		self.resultViewer.layout().setMargin(0)
		self.resultViewer.layout().addWidget(self.resultWidgetViewer)
		self.resultViewer.layout().addWidget(self.resultPlainTextViewer)
		self.resultViewer.layout().addWidget(self.resultHTMLViewer)
		self.resultRawViewer = QPlainTextEdit()
		self.resultRawViewer.setReadOnly(True)
		self.resultRawViewer.setStyleSheet("background-color:black;color:white;");
		self.resultRawViewer.setFont(QFont("Courier", 10))
#		self.resultRawViewer.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
#		self.resultRawViewer.setTabStopDistance(32)
		self.resultSourceViewer = QPlainTextEdit()
		self.resultSourceViewer.setReadOnly(True)
		self.resultSourceViewer.setStyleSheet("background-color:black;color:white;");
		self.resultSourceViewer.setFont(QFont("Courier", 10))
		self.resultSourceViewer.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
		self.resultSourceViewer.setTabStopDistance(32)
		
		#-- setup result tab
		self.resultTab = QTabWidget()
		self.resultTab.setTabPosition(QTabWidget.South)
		self.resultTab.addTab(self.resultViewer, 'Preview')
		self.resultTab.addTab(self.resultRawViewer, 'Raw')
		self.resultTab.addTab(self.resultSourceViewer, 'Source')
		
		# Right
		resultInfoLayout = QHBoxLayout()
		resultInfoLayout.addWidget(QLabel('Module:'))
		resultInfoLayout.addWidget(self.resultInfoLabel)
		resultInfoLayout.addStretch(1)
		rightLayout = QVBoxLayout()
		rightLayout.addLayout(resultInfoLayout)
		rightLayout.addWidget(self.resultTab)
		self.rightGroupBox = QGroupBox('Result')
		self.rightGroupBox.setLayout(rightLayout)
		self.rightGroupBox.hide()

		# Top Layout
		topLayout = QHBoxLayout()
		topLayout.addWidget(QLabel('Package Path'))
		topLayout.addWidget(self.txtSourcePath)
		topLayout.addWidget(self.btnReload)
		
		# Middle
		middleSplitter = QSplitter()
		middleSplitter.addWidget(leftGroupBox)
		middleSplitter.addWidget(self.rightGroupBox)
		
		# -- setup Master Layout
		masterLayout = QVBoxLayout()
		masterLayout.addLayout(topLayout)
		masterLayout.addWidget(middleSplitter)
		self.setLayout(masterLayout)
	
	def reloadCollection(self):
		self.clearTable()
		self.clearResultBox()
		path = self.txtSourcePath.text()
		if path.startswith('/'): path = '/' + path.strip('/')
		else: path = path.strip('/')
		
		# start with module table only if first load or reload
		if self.moduleService == None or self.moduleService.path != path:
			self.rightGroupBox.hide()
			self.globalParamBox.hide()
		
		if not os.path.isdir(path):
			self.statusChanged.emit('Invalid directory')
			return
		#end if
		
		self.resultTab.setCurrentIndex(0)
		
		source = self.setModuleService(path)
		self.parent().setPackageTitle(self.moduleService.packageName)
		sourceModuleNames = self.moduleService.moduleNames

		for moduleName in sourceModuleNames:
			self.table.insertRow(self.tableItems)
			moduleMeta = self.moduleService.getModuleMeta(moduleName)
			moduleLabel = self.getModuleLabel(moduleName)
			
			colName = QTableWidgetItem(moduleLabel)
			colName.setFlags(Qt.ItemIsSelectable | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
			colName.setCheckState(Qt.Unchecked)
			colName.setToolTip(moduleLabel)
			if moduleMeta.get('checked', False) == True: colName.setCheckState(Qt.Checked)
			
			colStatus = QTableWidgetItem('')
			colStatus.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
			colStatus.setTextAlignment(Qt.AlignCenter | Qt.AlignVCenter)
			colMessage = QTableWidgetItem('')
			#colMessage.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
			
			self.table.setItem(self.tableItems, 0, colName)
			self.table.setItem(self.tableItems, 1, colStatus)
			self.table.setItem(self.tableItems, 2, colMessage)
			
			self.tableItems += 1
		#end for
		
		meta = self.moduleService.packageMeta
		if meta.get('showGeneralParameter', None) == True:
			self.globalParamBox.show()
		elif meta.get('showGeneralParameter', None) == False:
			self.globalParamBox.hide()
		#end if
		if meta.get('showResultViewer', None) == True:
			self.rightGroupBox.show()
		elif meta.get('showResultViewer', None) == False:
			self.rightGroupBox.hide()
		#end if
		if meta.get('autorun', False) == True:
			self.runAllModuleItems()
		#end if
			
		self.statusChanged.emit('Modules reloaded')
	
	def hideAllResultViewers(self):
		self.resultWidgetViewer.hide()
		self.resultPlainTextViewer.hide()
		self.resultHTMLViewer.hide()
		
	def setResultWidgetViewer(self, content=None):
		layout = self.resultWidgetViewer.layout()
		widgetItem = layout.takeAt(0)
		if widgetItem:
			widget = widgetItem.widget()
			widget.setParent(None)
		#end if
		
		if content:
			print('add widget ' + str(content))
			layout.addWidget(content)
	
	def clearResultBox(self):
		self.resultInfoLabel.setText('')
		self.resultCurrentModuleName = ''
		self.hideAllResultViewers()
		self.resultPlainTextViewer.clear()
		self.resultHTMLViewer.clear()
		self.setResultWidgetViewer()
		self.resultRawViewer.clear()
		self.resultSourceViewer.clear()
	
	def getModuleNameFromTable(self, row):
		return self.table.item(row, 0).text().split(' ',1)[0]
	
	def getModuleLabel(self, moduleName):
		moduleMeta = self.moduleService.getModuleMeta(moduleName)
		title = moduleMeta['title'] if moduleMeta and 'title' in moduleMeta else ''
		return moduleName if len(title) == 0 else moduleName + ' - ' + title
	
	def runModule(self, moduleName, row):
		self.statusChanged.emit('running ' + moduleName)
		result = self.moduleService.runModule(moduleName, self.txtGlobalParam.text())
		self.table.item(row, 1).setText(result['status'])
		self.table.item(row, 1).setToolTip(result['status'])
		self.table.item(row, 2).setText(result['message'])
		self.table.item(row, 2).setToolTip(result['message'])
		self.resultViewPool[moduleName] = None
		return result
	
	def getResultViewItem(self, moduleName):
		if moduleName in self.resultViewPool:
			moduleResultView = self.moduleService.getModuleResultView(moduleName)
			moduleMeta = self.moduleService.getModuleMeta(moduleName)
			if isinstance(moduleResultView, QWidget) and moduleMeta.get('useResultViewerScrollArea',True):
				scrollArea = QScrollArea()
				scrollArea.setWidget(moduleResultView)
				moduleResultView = scrollArea
			result = self.moduleService.getModuleLastResult(moduleName)
			pp = pprint.PrettyPrinter()
			self.resultViewPool[moduleName] = {
				'resultView': moduleResultView,
				'raw': pp.pformat(result)
			}
			return self.resultViewPool[moduleName]
		#end if
	
	def applyResult(self, moduleName):
		self.clearResultBox()
		self.resultCurrentModuleName = moduleName
		self.resultInfoLabel.setText(self.getModuleLabel(moduleName))
		self.resultSourceViewer.insertPlainText(self.moduleService.getModuleSource(moduleName))
		resultViewItem = self.getResultViewItem(moduleName)
		
		if resultViewItem:
			self.resultRawViewer.insertPlainText(resultViewItem['raw'])
			moduleMeta = self.moduleService.getModuleMeta(moduleName)
			if self.moduleService.isModuleHasResultView(moduleName) and moduleMeta.get('requireResultViewer', None) != False:
				self.rightGroupBox.show()
			
			if type(resultViewItem['resultView']) is str:
				if (moduleMeta.get('resultTextFormat', None) == 'html'):
					self.resultHTMLViewer.setHtml(resultViewItem['resultView'])
					self.resultHTMLViewer.show()
				else:
					self.resultPlainTextViewer.insertPlainText(resultViewItem['resultView'])
					self.resultPlainTextViewer.show()
			elif isinstance(resultViewItem['resultView'], QWidget):
				self.setResultWidgetViewer(resultViewItem['resultView'])
				self.resultWidgetViewer.show()
	
	def runModuleItem(self):
		self.btnRunSourceModule.setEnabled(False)
		row = self.table.currentItem().row()
		moduleName = self.getModuleNameFromTable(row)
		self.runModule(moduleName, row)
		self.applyResult(moduleName)
		self.btnRunSourceModule.setEnabled(True)
		self.statusChanged.emit('finish running module')
		
	def runAllModuleItems(self):
		self.btnRunSourceModules.setEnabled(False)
		for row in range(self.table.rowCount()):
			if self.table.item(row, 0).checkState():
				moduleName = self.getModuleNameFromTable(row)
				self.runModule(moduleName, row)
		#end for
		self.btnRunSourceModules.setEnabled(True)
		self.statusChanged.emit('finish running all modules')
	#end def

	def clearTable(self):
		self.table.setRowCount(0)
		self.tableItems = 0
		
	def setModuleService(self, path):
		if self.moduleService:
			self.moduleService.destroy()
			for moduleName,resultViewItem in self.resultViewPool.items():
				if resultViewItem and isinstance(resultViewItem['resultView'], QWidget):
					resultViewItem['resultView'].setParent(None)
					resultViewItem['resultView'].deleteLater()
			self.resultViewPool = {}
		#end if
		
		self.moduleService = ModuleService(path) if path else None
	
	@Slot()
	def quitApp(self):
		self.parent().quitApp(None)
	
	@Slot()
	def cellClicked(self, row, col):
		moduleName = self.getModuleNameFromTable(row)
		self.btnRunSourceModule.setEnabled(True)
		
		if self.resultCurrentModuleName != moduleName:
			self.resultCurrentModuleName = moduleName
		#end if
		self.applyResult(moduleName)
	
	@Slot()
	def itemSelectionChanged(self):
		if len(self.table.selectedItems()) == 0:
			self.btnRunSourceModule.setEnabled(False)
		#end if
		
	@Slot()
	def toggleGeneralParameter(self):
		self.globalParamBox.setVisible(not self.globalParamBox.isVisible())
		
	@Slot()
	def toggleResultViewer(self):
		self.rightGroupBox.setVisible(not self.rightGroupBox.isVisible())
		
	@Slot()
	def startNew(self):
		self.rightGroupBox.hide()
		self.globalParamBox.hide()
		self.clearTable()
		self.clearResultBox()
		self.setModuleService(None)
