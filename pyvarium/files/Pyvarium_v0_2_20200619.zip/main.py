import sys
import os
from PySide2.QtWidgets import QApplication, QDesktopWidget, QStyleFactory

initial_collection_path = './Collections/Welcome'
app_version_default = '0.3'

def existsVersion(version):
	return os.path.isdir(app_cwd + '/Versions/' + version)

app_cwd = os.path.dirname(os.path.realpath(__file__))
app_version = sys.argv[1] if len(sys.argv) > 1 and existsVersion(sys.argv[1]) else app_version_default
app_profile = ''
session = {}

# append application version path
sys.path.append('./Versions/' + app_version + '/')

from App.MainWindow import MainWindow
from App.MainWidget import MainWidget

if __name__ == "__main__":
	# Qt Application
	app = QApplication(sys.argv)
	app.setApplicationName("Pyvarium")
	app.setStyle(QStyleFactory.create('Fusion'))
	
	# Central Widget
	mainWidget = MainWidget(initialCollectionPath=initial_collection_path)
	
	# QMainWindow using central widget
	window = MainWindow(app, mainWidget, appVersion=app_version)
	window.resize(1000, 600)
	
	qtRectangle = window.frameGeometry()
	centerPoint = QDesktopWidget().availableGeometry().center()
	qtRectangle.moveCenter(centerPoint)
	window.move(qtRectangle.topLeft())
	
	window.show()

	# Execute application
	sys.exit(app.exec_())
