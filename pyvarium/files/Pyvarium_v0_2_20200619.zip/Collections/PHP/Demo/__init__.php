<?php
namespace Demo;

const meta = [
	'autorun' => true,
];

