<?php
namespace Demo\TestHTML;

const meta = [
	'checked' => true,
	'viewTextFormat' => 'html',
];

function run($args=null, &$serviceData=[]){
	return ['status' => 'ok', 'message' => 'hello python'];
}

function view($result=[], &$serviceData=[]){
	return <<<HTML
<h1>This is PHP</h1>
<p>
	Welcome to the world wild web!
</p>
HTML;
}

