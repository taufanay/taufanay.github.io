import os

counter = 0

def countWithGlobal():
	global counter
	counter = counter + 1
	return {'status':'ok', 'message':counter}

def countWithFile(filename):
	if os.path.isfile(filename):
		f = open(filename, 'r')
		count = f.read()
		f.close()
	else:
		count = 0
	count = int(count) + 1
	f = open(filename, 'w')
	f.write(str(count))
	f.close()
	return {'status':'ok','message':count}

def run(args, **kwargs):
	#return countWithGlobal()
	path = kwargs['path']
	filename = path + '/counter'
	return countWithFile(filename)
