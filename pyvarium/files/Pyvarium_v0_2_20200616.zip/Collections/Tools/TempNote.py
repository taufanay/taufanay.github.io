from PySide2.QtWidgets import QTextEdit
import time
from threading import Timer

meta = {
	'checked':True
}

textEdit = QTextEdit()
lastTypingTime = time.time()
idleTime = 0.5
appSession = None

def run(args, **kwargs):
	global appSession
	moduleService = kwargs['moduleService']
	appSession = moduleService.getApplicationSession()
	if 'sessionNote' not in appSession: appSession['sessionNote'] = ''
	return {'status':'ok', 'message':'temporary notes until application closed'}
	
def view(result, **kwargs):
	textEdit.setPlainText(appSession['sessionNote'])
	textEdit.textChanged.connect(onTextChanged)
	return textEdit

def saveIfIdle():
	if (time.time() - lastTypingTime) > idleTime:
		text = textEdit.toPlainText()
		if appSession['sessionNote'] != text:
			appSession['sessionNote'] = text
			print('TempNote changes saved')
	pass

def onTextChanged():
	global lastTypingTime
	lastTypingTime = time.time()
	t = Timer(idleTime + 0.5, saveIfIdle)
	t.start()
