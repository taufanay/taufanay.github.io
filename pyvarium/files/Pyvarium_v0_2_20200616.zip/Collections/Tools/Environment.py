import platform
import sys
import os

def run(params, **kwargs): 
	return {
		'status': 'ok', 
		'message': 'Python version ' + platform.python_version(),
		'data': {
			'version': platform.python_version(),
			'buildNo': platform.python_build()[0],
			'buildDate': platform.python_build()[1],
			'system': platform.system(),
			'machine': platform.machine(),
			'architecture': platform.architecture()[0],
		}
	}
def view(result, **kwargs):
	moduleKeys = list(sys.modules.keys())
	moduleKeys.sort()
	moduleList = ''
	for module in moduleKeys: moduleList = moduleList + f"- {module}\n";
	
	envVars = list(os.environ.keys())
	envVars.sort()
	envList = ''
	for var in envVars: envList = envList + f"{var}: {os.environ.get(var)}\n"
	
	return f"""Platform & Environment Information

[Python]
version: {result['data']['version']}
build no: {result['data']['buildNo']}
build date: {result['data']['buildDate']}

[System]
system: {result['data']['system']}
machine: {result['data']['machine']}
architecture: {result['data']['architecture']}

[Modules]
{moduleList}

[Environment Variables]
{envList}
"""

if __name__ == '__main__':
	print(view(run(None)))
