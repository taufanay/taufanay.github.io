"""
Package magic file
"""

import sys
import os
from PySide2.QtWidgets import QApplication, QDesktopWidget, QStyleFactory

__import__(__name__ + '.Versions.v0_4.App.MainWindow')
__import__(__name__ + '.Versions.v0_4.App.MainWidget')
MainWindow = getattr(sys.modules[__name__ + '.Versions.v0_4.App.MainWindow'], 'MainWindow')
MainWidget = getattr(sys.modules[__name__ + '.Versions.v0_4.App.MainWidget'], 'MainWidget')

def run(args = None, **kwargs):
	window = kwargs['window']
	return MainWidget(window)
	
