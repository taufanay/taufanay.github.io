import sys
import os
from PySide2.QtWidgets import QApplication, QDesktopWidget, QStyleFactory

initial_collection_path = './Collections/Welcome'
app_version_default = 'v0_3'

def existsVersion(version):
	exists = os.path.isdir(app_dir + '/Versions/' + version)
	if not exists: 
		print('version ' + version + ' not exists')
		sys.exit()
	return exists

app_dir = os.path.dirname(os.path.realpath(__file__))
app_version = sys.argv[1] if len(sys.argv) > 1 and existsVersion(sys.argv[1]) else app_version_default
app_profile = ''
session = {}

# append application version path

def initApp():
	# Qt Application
	app = QApplication(sys.argv)
	app.setApplicationName("Pyvarium")
	app.setStyle(QStyleFactory.create('Fusion'))
	return app

def initWindow(app, MainWindow, MainWidget):
	window = None
	if app_version in ['v0_2','v0_3']:
		mainWidget = MainWidget(initialCollectionPath=initial_collection_path)
		window = MainWindow(app, mainWidget, appVersion=app_version)
	else:
		mainWidget = MainWidget()
		mainWindow = MainWindow(app, mainWidget, appVersion=app_version)
		window = mainWindow.window()

	window.resize(1000, 600)
	qtRectangle = window.frameGeometry()
	centerPoint = QDesktopWidget().availableGeometry().center()
	qtRectangle.moveCenter(centerPoint)
	window.move(qtRectangle.topLeft())
	return window

def startApp(app, window):
	window.show()
	# Execute application
	sys.exit(app.exec_())

if __name__ == '__main__':
	print("To properly start this application, run \"python3 Pyvarium\" from the parent directory of this file")
