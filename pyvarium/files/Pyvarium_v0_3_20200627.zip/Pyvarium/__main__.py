"""
Console entry point magic file
"""

import sys
import main

if __name__ == "__main__":
	sys.path.append(main.app_dir + '/Versions/' + main.app_version)
	from App.MainWindow import MainWindow
	from App.MainWidget import MainWidget

	app = main.initApp()
	window = main.initWindow(app, MainWindow, MainWidget)
	main.startApp(app, window)
	
