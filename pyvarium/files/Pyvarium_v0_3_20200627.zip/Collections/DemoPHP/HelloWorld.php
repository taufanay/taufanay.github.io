<?php
namespace DemoPHP\HelloWorld;

const meta = [
	'viewTextFormat' => 'html'
];

function run($args=null, $serviceData=[]){
	return ['status' => 'ok', 'message' => 'hello Pyvarium'];
}

function view($result=[], $serviceData=[]){
	return <<<HTML
<h1>This is PHP</h1>

<p>
${result['message']}
</p>
HTML;
}

if ($argc > 0 && basename(__FILE__) == $argv[0]) { // run directly from command line
	echo view(run());
}

