import sqlite3
import csv
import os
import time

meta = {'title':'Export to CSV'}
export_directory = 'export'

def run(args=None, **kwargs):
	file = args if args else ''
	if len(file) == 0: return {'status':'fail','message':'please provide a file name'}
	if not os.path.isfile(file): return {'status':'fail','message':'invalid file'}
	
	conn = sqlite3.connect(file)
	c = conn.cursor()
	tableNames = getTableNames(c)
	createdAt = str(int(time.time()))
	exportDir = prepareCsvDirectory(os.path.dirname(os.path.dirname(file)))
	dbBase = os.path.splitext(os.path.basename(file))[0]
	dirBase = os.path.join(exportDir, dbBase + '.' + createdAt)
	os.mkdir(dirBase) # create by db directory
	fileNames = []
	for tableName in tableNames:
		sql = f"SELECT * FROM {tableName}"
		fileNames.append(tableName + ".csv")
		c.execute(sql)
		with open(os.path.join(dirBase, fileNames[-1]), "w") as fcsv:
			csvWriter = csv.writer(fcsv)
			csvWriter.writerow([i[0] for i in c.description]) # write headers
			csvWriter.writerows(c)
	return {'status':'ok',
	        'message':str(len(tableNames)) + ' csv files created',
	        'data':{'dir':dirBase,
	                'files':fileNames}}

def getTableNames(c):
	sql = "SELECT name FROM sqlite_master WHERE type='table';"
	tableNames = []
	for row in c.execute(sql): tableNames.append(row[0])
	return tableNames

def prepareCsvDirectory(baseDir):
	exportDir = os.path.join(baseDir, export_directory)
	if not os.path.isdir(exportDir): os.mkdir(exportDir)
	return exportDir

def view(result, **kwargs):
	data = result['data']
	
	def drawFileList():
		text = ''
		for fileName in result['data']['files']: text = text + f"- {fileName}\n"
		return text

	return f"""Export Information

Directory:
{data['dir']}

Files:
{drawFileList()}
"""



