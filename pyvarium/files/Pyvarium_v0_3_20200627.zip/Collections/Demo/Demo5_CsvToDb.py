import os
import csv
import sqlite3
import datetime

meta = {'title':'Create Db'}
db_directory = 'db'
dir = ''

def run(args=None, **kwargs):
	global dir
	if args: dir = args.rstrip('//')
	if len(dir) == 0: return {'status':'fail','message':'Please provide directory'}
	if not os.path.isdir(dir): return {'status':'fail','message':'Invalid directory'}
	csvList = getCSVList()
	if not csvList:
		return {'status':'fail', 'message':'No csv file in directory'}
	dbFilename = createSQLite(csvList)
	tableInfos = readSQLite(os.path.join(dir,db_directory + '/' + dbFilename))
	if not dbFilename: 
		return {'status':'fail','message':'Due for some reasons'}
	return {'status':'ok', 
	        'message':db_directory + '/' + dbFilename,
	        'data':{'database':dbFilename,
	                'tableInfos':tableInfos}}

def getCSVList():
	csvList = []
	files = os.listdir(dir)
	for fname in files:
		fullFilename = os.path.join(dir,fname)
		if os.path.isfile(fullFilename) and fname[-4:] == '.csv':
			csvList.append(fullFilename)
	return csvList

def createSQLite(csvList):
	headersMap = {}
	for csvFile in csvList:
		header = parseCSVHeader(csvFile)
		if header: headersMap[csvFile] = header
	if headersMap:
		createdAt = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
		dbFilename = createdAt + '.sqlite3'
		dbDir = prepareDbDirectory(dir)
		conn = sqlite3.connect(os.path.join(dbDir, dbFilename))
		c = conn.cursor()
		for csvFile, headers in headersMap.items():
			tableName = os.path.basename(csvFile)[:-4]
			joinFields = ','.join(headers)
			sql = f"CREATE TABLE {tableName} ({joinFields})"
			c.execute(sql)
			with open(csvFile) as fcsv:
				reader = csv.reader(fcsv)
				firstLine = True
				for row in reader:
					if firstLine: firstLine = False
					else:
						valuesPlaceholder = ','.join(['?'] * len(row))
						sql = f"INSERT INTO {tableName} ({joinFields}) VALUES ({valuesPlaceholder})"
						c.execute(sql, row)
		conn.commit()
		conn.close()
		return dbFilename

def parseCSVHeader(filename):
	with open(filename) as fcsv:
		headers = None
		reader = csv.reader(fcsv)
		for row in reader:
			headers = row
			break
		return headers

def prepareDbDirectory(baseDir):
	dbDir = os.path.join(baseDir, db_directory)
	if not os.path.isdir(dbDir): os.mkdir(dbDir)
	return dbDir

def readSQLite(file):
	conn = sqlite3.connect(file)
	c = conn.cursor()
	tableNames = getTableNames(c)
	tableInfos = []
	for tableName in tableNames:
		sql = f"SELECT COUNT(*) FROM {tableName}"
		c.execute(sql)
		count = c.fetchone()[0]
		tableInfos.append({'table':tableName,'rows':count})
	conn.close()
	return tableInfos

def getTableNames(c):
	sql = "SELECT name FROM sqlite_master WHERE type='table';"
	tableNames = []
	for row in c.execute(sql): tableNames.append(row[0])
	return tableNames

def view(result, **kwargs):
	database = result['data']['database']
	tableInfos = result['data']['tableInfos']

	def drawInfo():
		text = ''
		for info in tableInfos: text = text + f"- {info['table']}: {info['rows']} rows\n"
		return text

	return f"""Database Information

Database file:
{database}

Tables:
{drawInfo()}
"""


