Pyvarium

====================
Starting Application
====================
1. Open terminal or command line;
2. Go to the directory of this file (readme.txt),
   this will set our working directory here,
   and I assume we are already in this directory;
3. Run one of these commands:
   > python3 Pyvarium

