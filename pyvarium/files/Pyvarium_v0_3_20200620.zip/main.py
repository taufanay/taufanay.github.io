import sys
import os
from PySide2.QtWidgets import QApplication, QDesktopWidget, QStyleFactory

initial_collection_path = './Collections/Welcome'
app_version_default = '0.3'

def existsVersion(version):
	exists = os.path.isdir(app_cwd + '/Versions/' + version)
	if not exists: 
		print('version ' + version + ' not exists')
		sys.exit()
	return exists

app_cwd = os.path.dirname(os.path.realpath(__file__))
app_version = sys.argv[1] if len(sys.argv) > 1 and existsVersion(sys.argv[1]) else app_version_default
app_profile = ''
session = {}

# append application version path
sys.path.append('./Versions/' + app_version + '/')
from App.MainWindow import MainWindow

def setWindowVersion01():
	from App.MainWidget import MainWidget
	mainWidget = MainWidget(initialCollectionPath=initial_collection_path)
	return MainWindow(app, mainWidget, appVersion=app_version)

if __name__ == "__main__":
	# Qt Application
	app = QApplication(sys.argv)
	app.setApplicationName("Pyvarium")
	app.setStyle(QStyleFactory.create('Fusion'))
	
	if app_version in ['0.2','0.3']:
		window = setWindowVersion01()
	else:
		window = MainWindow(app, appVersion=app_version)
	
	window.resize(1000, 600)
	
	qtRectangle = window.frameGeometry()
	centerPoint = QDesktopWidget().availableGeometry().center()
	qtRectangle.moveCenter(centerPoint)
	window.move(qtRectangle.topLeft())
	window.show()

	# Execute application
	sys.exit(app.exec_())
