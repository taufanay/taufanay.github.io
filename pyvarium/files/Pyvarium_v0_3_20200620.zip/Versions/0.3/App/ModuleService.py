import os
import sys
import collections

from abc import ABC, abstractmethod
from importlib import reload

STATUS_OK = 'ok'
STATUS_FAIL = 'fail'
STATUS_ERROR = 'error'

class ModuleService():
	def __init__(self, path):
		self.path = ''
		self.packageName = ''
		self.initModule = None
		self.packageMeta = {}
		self.moduleNames = []
		self.lastResults = {}
		self.session = {}
		self.path = os.path.realpath(path)
		self.packageName = os.path.basename(path)
		
		self._initInstance()
		self._initModuleNames()
		self._initPackage()
	
	@abstractmethod
	def _initInstance(self): pass
	
	@abstractmethod
	def _initPackage(self): pass
		
	@abstractmethod
	def getModule(self, moduleName): pass

	@abstractmethod
	def reloadModule(self, moduleName): pass

	@abstractmethod
	def getModuleMeta(self, moduleName): pass
	
	@abstractmethod
	def destroy(self): pass
	
	def _initModuleNames(self):
		modulePath = self.path
		files = os.listdir(modulePath)
		for fname in files:
			filename, file_extension = os.path.splitext(fname)
			if os.path.isfile(os.path.join(modulePath,fname)) and (fname != self.initFileName) and file_extension == '.'+self.moduleFileExtension:
				self.moduleNames.append(fname[:-len(file_extension)])
		self.moduleNames.sort()
	
	def getModuleLastResult(self, moduleName):
		result = None
		if moduleName in self.lastResults:
			result = self.lastResults[moduleName]
		return result
		
	def getModuleLastResultStatus(self, moduleName):
		return self.getModuleLastResult(moduleName)['status']
	
	def getModuleLastResultMessage(self, moduleName):
		return self.getModuleLastResult(moduleName)['message']
	
	def getModuleLastResultData(self, moduleName):
		return self.getModuleLastResult(moduleName)['data']
		
	def runModule(self, moduleName, params):
		module = self.reloadModule(moduleName)
		#module = self.getModule(moduleName)
		if hasattr(module, 'run'):
			definition = getattr(module, 'run')
			try:
				result = definition(params, moduleService=self)
			except Exception as ex:
				result = {'status':'error', 'message': str(ex)}
			except:
				o = sys.exc_info()[0]
				result = {'status':'error', 'message': str(0)}
			
			if isinstance(result, collections.Mapping):
				self.lastResults[moduleName] = result
			else:
				self.lastResults[moduleName] = {
					'status': 'n/a',
					'message': '(invalid result type)',
					'data': result
				}
		else:
			self.lastResults[moduleName] = {
				'status': 'n/a',
				'message': '(nothing to run)',
				'data': None
			}
			
		return self.lastResults[moduleName]
	
	def isModuleHasResultView(self, moduleName):
		return hasattr(self.getModule(moduleName), 'view')
	
	def getModuleResultView(self, moduleName):
		lastResult = self.getModuleLastResult(moduleName)
		if lastResult['status'] == 'ok':
			module = self.getModule(moduleName)
			if hasattr(module, 'view'):
				return getattr(module, 'view')(lastResult, moduleService=self)
	
	def getModuleSource(self, moduleName):
		f = open(os.path.join(self.path, moduleName + '.' + self.moduleFileExtension))
		source = f.read()
		f.close()
		return source
	
	def getSession(self):
		return self.session
	
	def getApplicationSession(self):
		from main import session
		return session
		
	def serialize(self):
		return json.dumps([])
