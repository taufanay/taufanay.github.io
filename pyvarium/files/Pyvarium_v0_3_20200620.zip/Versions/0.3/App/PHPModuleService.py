from App.ModuleService import ModuleService
import os
import json

class PHPModuleService(ModuleService):
	def _initInstance(self):
		self.initFileName = '__init__.php'
		self.moduleFileExtension = 'php'
		self.packageAttributes = {}
		self.moduleAttributes = {}
		self.moduleResultPacks = {}
	
	def runPackageResolver(self, method, args=[]):
		from main import app_version, app_cwd
		cmd = f"cd {self.path};php {app_cwd}/Versions/{app_version}/PHPPackageResolver.php {method}"
		stream = os.popen(cmd)
		output = stream.read()
		try:
			outputData = json.loads(output)
		except Exception(ex):
			print(output)
			raise ex
		return outputData
		
	def _initPackage(self):
		packageAttributesPack = self.runPackageResolver('init')
		self.packageAttributes = packageAttributesPack['packageAttributes']
		self.moduleAttributes = packageAttributesPack['moduleAttributes']
		if self.packageAttributes['meta']: self.packageMeta = self.packageAttributes['meta']
		print(packageAttributesPack)
	def getModuleMeta(self, moduleName):
		return self.moduleAttributes[moduleName]['meta'] if self.moduleAttributes[moduleName]['meta'] else {}
	
	def destroy(self): pass
	
	def runModule(self, moduleName, args):
		from main import app_version, app_cwd
		jsonArgs = json.dumps(args)
		jsonServiceData = json.dumps({
			'moduleService': {
				'path': self.path,
				'session': self.getSession(),
				}
			})
		cmd = f"cd {self.path};php {app_cwd}/Versions/{app_version}/PHPPackageResolver.php run {moduleName} {jsonArgs} {jsonServiceData}"
		stream = os.popen(cmd)
		output = stream.read()
		try:
			self.moduleResultPacks[moduleName] = json.loads(output)
		except Exception(ex):
			print(output)
			raise ex
		# update module meta
		self.moduleAttributes[moduleName]['meta'] = self.moduleResultPacks[moduleName]['meta']
		return self.moduleResultPacks[moduleName]['result']
	
	def getModuleLastResult(self, moduleName):
		result = None
		if moduleName in self.moduleResultPacks:
			result = self.moduleResultPacks[moduleName]['result']
		return result
	
	def isModuleHasResultView(self, moduleName):
		return self.moduleAttributes[moduleName]['canView']
	
	def getModuleResultView(self, moduleName):
		lastResult = self.getModuleLastResult(moduleName)
		if lastResult['status'] == 'ok':
			if self.isModuleHasResultView(moduleName):
				return self.moduleResultPacks[moduleName]['resultView']
