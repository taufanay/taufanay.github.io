meta = {
	'title': 'Documentation',
	'checked': True,
	'viewTextFormat': 'html',
}
	
def run(params, **kargs):
	return {
		'status': 'ok',
		'message': 'click to view',
	}

def view(result, **kargs):
	return """<h1>Documentation</h1>

<p>	
As you might know in the Getting Started section, there are 2 main components in this program, the <b>Package</b> directory and the <b>Module</b> scripts.
Your understanding about Package and Module in Python will be helpful, but if you still not familiar about it, don't worry, using this application should make you better understanding about it.
Let's learn together.
</p>

<h2>Package</h2>
<p>
This is the directory where modules reside.
For example, the current package of this Welcome modules can be viewed in the <b>./Collections/Welcome</b>.
</p>
<p>
This is actually an implementation of Python package where we can put any initialization script in a __init__.py file inside this directory.
To setup the package when we first open it, we put our metadata values in that initialization script.
Throughout the samples in this documentation we will use ./Collections/Demo/ as the Package directory.
</p>

<h3><i>Meta Dictionary</i></h3>
<p>
Package meta is called when the package opened. If you want to make change when application is running, you need to re-open the package.
</p>
<p style="background-color:snow;color:gray;padding:10px;">
<pre>
# .Collections/Demo/__init__.py
meta = {
  'autorun': True|False, # default is false
  'showResultViewer': True|False, # default is false
  'showGeneralParamater': True|False, # default is false
}
</pre>
</p>
<p>
All key-value in Package metadata are optional.
The metadata variable and the initialization file itself is also optional.
</p>

<h2>Module</h2>
<p>
A module is a file where the script we want to run and view either in Modules Table or Result Viewer.
To interact with GUI, our module should implement the corresponding attributes.
</p>
<h3><i>Meta Dictionary</i></h3>
<p>
Module meta is called when the package opened. If you want to make change when application is running, you need to re-open the package.
</p>
<p style="background-color:snow;color:gray;padding:10px;">
<pre>
# .Collections/Demo/[ModuleName].py
meta = {
  'title': 'Module Title', # default no title
  'checked': True|False, # default is false
  'requireResultViewer': True|False, # default is true if view function detected
  'viewTextFormat': 'plain'|'html' # default is plain
}
</pre>
</p>

<p>
Combination of 'checked' value in Module meta and 'autorun' value in Package meta can be used to automatically run all modules where user can just view the final result, just like this Welcome modules.
</p>

<h3><i>Run Function</i></h3>
<p>
	This function is called when user click the run button.
	Define <b>run</b> function with parameters such as (params, **kwargs).
	Return value must be a dictionary with mandatory item: <b>status</b>, <b>message</b>, and <b>data</b>.
</p>
<p style="background-color:snow;color:gray;padding:10px;">
<pre>
# .Collections/Demo/[ModuleName].py
def run(params, **kwargs):
  result = {
    'status':'ok'|'fail'|'error', # default will be n/a
    'message':'The result message', # default is empty
    'data': 'Can be any values and type',
  }
  return result
</pre>
</p>

<p>
If you want to make change when application is running, you just need to re-run the module.
</p>

<h3><i>View Function</i></h3>
<p>
	This function is called when user click in the Module Table a successful run module (status is 'ok').
	Define <b>view</b> function with parameters such as (result, **kwargs).
	Return value must be at least 2 kind data types, string or instance of QWidget.
</p>
<p style="background-color:snow;color:gray;padding:10px;">
<pre>
# .Collections/Demo/[ModuleName].py
from PySide2.QtWidgets import QLabel

def run(params, **kwargs): return {'status':'ok','message':'view sample'}
	
def view(result, **kwargs):
  resultView = \"\"\"View can be multiline plain text,\"\"\" | \"\"\"a <b>html</b> text,\"\"\" | QLabel('or a widget!')
  return resultView
</pre>
</p>

<p>
	The string return value format defined by the module meta attribute above, so the application understand how to show it either in plain or html.
</p>

<p>
If you want to make change when application is running, you just need to re-run the module.
Also be reminded, the behaviour of the Result Viewer is defined in Package meta and Module meta.
</p>
"""
