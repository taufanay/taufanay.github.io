meta = {
	'title': 'Getting Started',
	'checked': True,
	'viewTextFormat': 'html'
}
	
def run(params, **kargs):
	return {
		'status': 'ok',
		'message': 'click to view',
	}

def view(result, **kargs):
	return """<h1>Getting Started</h1>

<p>
Welcome to Pyvarium application.
</p>

<p>
Pyvarium is a simple general purpose script runner GUI tool to run one or more of your custom Python scripts.
The result output of these modules can be further processed to viewed as a textual format or graphical representation.
Hopefully this will make scripting tasks or learning much more convenience.
</p>

<h3>Use Cases</h3>
<p>
You might find find this application helpful when you do the following activities:
<ul>
	<li>learning,</li>
	<li>monitoring,</li>
	<li>execution,</li>
	<li>automation (maybe in the future version),</li>
	<li>analysis,</li>
	<li>data generation,</li>
	<li>user interactivity,</li>
	<li>etc.</li>
</ul>
</p>

<h3>Create Your First Module</h3>
<p>
To get started, I recommend you create a new directory first and create a new blank Python file inside the new directory, then copy the hello world snippet below.
</p>

<p style="background-color:snow;color:gray;padding:10px;">
<pre>
# sample file path: ./Collections/Demo/First.py
def run(params, **kwargs):
  return {
    "status": "ok",
    "message": "Hello World",
  }
</pre>
</p>

<p>
Next, type in the directory path in the application and click Open. When the file name appear in the Modules table, select the row and click Run.
If everything ok, you will see 'Hello World' in the Message column.
</p>

<p>
Because this application make use of the concept of "Module" and "Package" in Python, in this application, the new file you just created is also refered as "Module" and the directory where it reside is also refered as "Package".
There are more features beside displaying simple message. Complete specifications can be viewed in the next module in this Welcome package.
</p>
"""
