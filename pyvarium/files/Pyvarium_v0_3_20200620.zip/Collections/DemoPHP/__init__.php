<?php
namespace DemoPHP;

const meta = [
	'autorun' => true,
];


