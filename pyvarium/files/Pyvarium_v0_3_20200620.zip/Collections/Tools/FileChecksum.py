import hashlib
import os
import sys

meta = {
	'shortDesc': 'calculates md5 checksum of a file from general parameter' 
}

def run(params, **kwargs):
	status = 'fail'
	
	if len(params) == 0:
		msg = 'provide a path to file'
	elif not os.path.isfile(params):
		msg = 'file not found'
	else:
		status = 'ok'
		msg = hashlib.md5(open(params,'rb').read()).hexdigest()
	
	return {'status':status, 'message':msg, 'data': {'file':params}}
	
def view(result, **kwargs):
	return f"""File Checksum Result

File:
{result['data']['file']}

MD5 Checksum:
{result['message']}
"""

if __name__ == '__main__':
	param = sys.argv[1]
	print(view(run(param)))
