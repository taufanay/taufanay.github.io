import sys

def run(params, **kwargs):
	status = 'fail'
	
	if len(params) > 0:
		try:
			__import__(params)
			msg = f'"{params}" exists'
			status = 'ok'
		except:
			msg = f'"{params}" not exists'
			pass
	else:
		msg = 'provide a module name'
	
	return {'status': status, 'message':msg}
	
if __name__ == '__main__':
	param = sys.argv[1] if len(sys.argv) > 1 else ''
	print(run(param)['message'])
