def run(args, **kwargs):
	moduleService = kwargs['moduleService']
	helloWorldResult = moduleService.getModuleLastResult('HelloWorld')
	if helloWorldResult:
		result = {
			'status':'ok',
			'message': helloWorldResult['message']
		}
	else:
		result = {
			'status':'fail',
			'message':'Please run HelloWorld',
		}
	return result
