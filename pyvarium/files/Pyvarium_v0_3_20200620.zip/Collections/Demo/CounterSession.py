def run(args, **kwargs):
	moduleService = kwargs['moduleService']
	session = moduleService.getSession()
	count = session['count'] + 1 if 'count' in session else 0
	session['count'] = count

	appSession = moduleService.getApplicationSession()
	count2 = appSession['count'] + 1 if 'count' in appSession else 0
	appSession['count'] = count2

	return {'status':'ok','message':'session:{}, app session:{}'.format(count, count2)}
