from PySide2.QtGui import QPixmap
from PySide2.QtWidgets import QLabel
import os

img = os.path.dirname(__file__) + '/files/python-powered.png'

def run(params, **kwargs):
	return {
		'status':'ok',
		'message': img
	}

def view(result, **kwargs):
	view = QLabel()
	pixmap = QPixmap(img)
	view.setPixmap(pixmap)
	return view
